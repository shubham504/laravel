<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class GamesController extends Controller
{
    //
      public function create()
    {
        return view('registration.create');
    }
        public function store()
    {
        echo 'asdasd';
    }
}